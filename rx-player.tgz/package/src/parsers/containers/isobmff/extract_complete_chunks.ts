/**
 * Copyright 2015 CANAL+ Group
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { be4toi } from "../../../utils/byte_parsing";
import findCompleteBox from "./find_complete_box";

/**
 * Take a chunk of ISOBMFF data and extract complete `moof`+`mdat` subsegments
 * which are ready to be decoded.
 * Returns a tuple of two containing first an array of those subsegments
 * followed by the last un-decodable part.
 * @param {Uint8Array} buffer
 * @returns {Array}
 */
export default function extractCompleteChunks<T extends ArrayBufferLike>(
  buffer: Uint8Array<T>,
): [Array<Uint8Array<T>> | null, Uint8Array<T> | null] {
  let _position = 0;
  const chunks: Array<Uint8Array<T>> = [];
  let currentBuffer: null | Uint8Array<T> = null;
  while (_position <= buffer.length) {
    if (_position === buffer.length) {
      currentBuffer = null;
      break;
    }
    currentBuffer = buffer.subarray(_position, Infinity);
    const moofIndex = findCompleteBox(currentBuffer, 0x6d6f6f66 /* moof */);
    if (moofIndex < 0) {
      // no moof, not a media segment.
      break;
    }
    const moofLen = be4toi(buffer, moofIndex + _position);
    const moofEnd = _position + moofIndex + moofLen;
    if (moofEnd > buffer.length) {
      // not a complete moof segment
      break;
    }

    const mdatIndex = findCompleteBox(currentBuffer, 0x6d646174 /* mdat */);
    if (mdatIndex < 0) {
      // no mdat, not a segment.
      break;
    }
    const mdatLen = be4toi(buffer, mdatIndex + _position);
    const mdatEnd = _position + mdatIndex + mdatLen;
    if (mdatEnd > buffer.length) {
      // not a complete mdat segment
      break;
    }

    const maxEnd = Math.max(moofEnd, mdatEnd);
    const chunk = buffer.subarray(_position, maxEnd);
    chunks.push(chunk);

    _position = maxEnd;
  }
  if (chunks.length === 0) {
    return [null, currentBuffer];
  }
  return [chunks, currentBuffer];
}

/**
 * @param {Uint8Array} buffer
 * @returns {Array}
 */
export function extractInitSegment<T extends ArrayBufferLike>(
  buffer: Uint8Array<T>,
): [Uint8Array<T> | null, Uint8Array<T> | null] {
  const moovIndex = findCompleteBox(buffer, 0x6d6f6f76 /* moov */);
  if (moovIndex < 0) {
    // no moov, not an init segment.
    return [null, buffer];
  }
  const moovLen = be4toi(buffer, moovIndex);
  const moovEnd = moovIndex + moovLen;
  if (moovEnd > buffer.length) {
    // not a complete moov segment
    return [null, buffer];
  }
  return [buffer.subarray(0, moovEnd), buffer.subarray(moovEnd, Infinity)];
}
